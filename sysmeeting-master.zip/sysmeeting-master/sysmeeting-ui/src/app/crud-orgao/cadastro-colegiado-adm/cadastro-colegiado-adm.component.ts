import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastro-colegiado-adm',
  templateUrl: './cadastro-colegiado-adm.component.html',
  styleUrls: ['./cadastro-colegiado-adm.component.css']
})
export class CadastroColegiadoAdmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
