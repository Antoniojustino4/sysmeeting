import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastro-colegiado',
  templateUrl: './cadastro-colegiado.component.html',
  styleUrls: ['./cadastro-colegiado.component.css']
})
export class CadastroColegiadoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
